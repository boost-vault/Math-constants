// testFunctionConstants.cpp

// (C) Copyright Paul A Bristow, hetp Chromatography, 2001, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <iostream>
#include <limits> // for numeric_limits

#include "function_constants.hpp"
#include "gamma_function_constant.hpp"

using std::cout;
using std::endl;

const char nl = '\n';
const char tab = '\t';
const char space = ' ';

// Based on a post by Michael Kenniston:  http://groups.yahoo.com/group/boost/message/14867 

template <typename T>
void show_float_examples(const T& dummy_FPtype, const char* label)
{
  // The namespaces are not templated, but gurus can bypass the
  // namespaces and access all constants directly via template parameters.
  // Code like this would normally only be written by non-novices.
  // For example:   show_float_examples( double(), "double" );
  
  using namespace boost::math;
  cout << label << "pi = " << constant< T, pi_tag >() << "\n";
	// const T& dummy_FPtype is only needed to prevent MSVC 6.5 calling the wrong type.
	// May not bee needed for MSVC 7?
	// And warning C4100 that is unreferenced formal parameter.
}

const double constpi = 3.141592653589793238462643383279502884197;

double dummy; // Used only to prevent optimisation during test.

int main()
{


	cout << "Test " << __FILE__ << ' ' << __TIMESTAMP__ << endl;
	
	{ // How to provide an alias?
		const double pi_twice = constpi + constpi;
   #define two_pi pi_twice // alias

		cout << two_pi << endl;
		cout << pi_twice << endl;
	}

	// Calculate number of significant digits, strictly
	// ceil(1 + std::numeric_limits<float>::digits*log10(2.))
	// but need an approximation that does not use floating-point
	// to compute correctly at compile time.
	int float_significand_digits =  std::numeric_limits<float>::digits; // 24 bits
	int float_significant_digits =  2 + float_significand_digits * 30101/100000;
	int double_significand_digits =  std::numeric_limits<double>::digits; // 53 bits
	int double_significant_digits =  2 + double_significand_digits * 30101/100000; // 53 bits for MSVC
	cout.precision(double_significant_digits);// Ensure they are all output.

	// Select an entire set of constants with a single using directive:
	using namespace boost::math::double_constants;
	
	// So naive users (mea culpa) can just say "pi",
	// and get boost::math::double_constants::pi.

  // Or can select float constants:
  // using namespace boost::math::float_constants;
	// and get boost::math::float_constants::pi.

	/*
	const double cp = 3.141592653589793238462643383279502884197;
	double ccp = constpi;
	dummy = ccp;
	double pd = 3.141592653589793238462643383279502884197;
	dummy = pd; // Prevent optimisation during testing.
	*/

	double p = pi; // Assignment using function.
	dummy = p; // Prevent optimisation to observe in assembly code.
	const double cp = pi; // Assignment using function.
	cout << "pi = " << pi << "\n";

	cout << "const pi = " << cp << "\n";
	double r = 2.0;
	double area = pi * r * r;
	cout << "area = " << area << endl;
	
	// Naughty users can write pi = 3.; but WON'T compile!
	// but they get a deservedly cryptic error message:
	// C2678: binary '=' : no operator defined which takes a left-hand operand of type
	// 'const struct boost::math::constant<struct boost::math::pi_tag,double>'
	
	// Or for using float and double constants at the same time,
	// users can explicitly access fully specified constants at any time:
	cout.precision(float_significant_digits);
	// Ensure all float significant digits are displayed (9).
	cout << "float pi = " << boost::math::float_constants::pi << "\n";
	cout.precision(double_significant_digits);
	cout << "double pi = " << boost::math::double_constants::pi << "\n";

	using namespace boost::math; // To shorten usage to "float_constants::pi".
	cout.precision(float_significant_digits);
	cout << "float pi = " << float_constants::pi << "\n";
	cout.precision(double_significant_digits);
	cout << "double pi = " << double_constants::pi << "\n";
	
	// But one CANNOT switch to float_constants from previous
	// using namespace boost::math::double_constants;
	// thus:

  // using namespace boost::math::float_constants; // is OK for MSVC 7.0

	// But writing:
  // cout << "float pi = " << pi << "\n";
	// fails to compile - MSVC error C2872: 'pi' : ambiguous symbol
	// probably a useful safeguard
	// against using TWO  "using namespace boost::math::..." statements!
	// Caution: this could happen through #including 
	// and this message warns hints darkly that this has happened!
	
	// For types that are not specialised, for example short, one could write:
	const short pi_si = static_cast<short>(boost::math::float_constants::pi);
	cout << "short pi = " << pi_si << '\n';  // short integer pi is 3!

	// Access via the templated function call may allow better optimisation?
	float pi_f = boost::math::constant< float, pi_tag >();
	// See below for some assembler output - YMMV
	cout << "boost::math::constant< float, pi_tag >() " << pi_f << endl;
	
	// If a template is not specialised for the type, then fails at link time.
	
  // Exercise 'guru' code.
	cout.precision(double_significant_digits);
  show_float_examples( double(), "double" );

  cout.precision(float_significant_digits);
	show_float_examples( float(),  "float" );

	// More examples:
	cout << "sqrt2 = " << sqrt2 << endl;
	cout << "e = " << e << endl;

	// Examples of constant added by #include "gamma_function_constant.hpp"

	cout << "gamma = " << gamma << endl;

	return 0;
} // main

/*

Output is:

Test testFunctionConstants.cpp Thu Dec 12 22:15:58 2002
6.28319
6.28319
pi = 3.1415926535897931
const pi = 3.1415926535897931
area = 12.566370614359172
float pi = 3.14159274
double pi = 3.1415926535897931
float pi = 3.14159274
double pi = 3.1415926535897931
short pi = 3
boost::math::constant< float, pi_tag >() 3.1415927410125732
doublepi = 3.1415926535897931
floatpi = 3.14159274
sqrt2 = 1.41421356
e = 2.71828183
gamma = 0.577215665
Press any key to continue


Some assembly code showing optimisation potential.

51:       const double cp = 3.141592653589793238462643383279502884197;
00401650   mov         dword ptr [ebp-8],54442D18h
00401657   mov         dword ptr [ebp-4],400921FBh

52:       double ccp = constpi;
0040165E   mov         eax,[constpi (00470028)]
00401663   mov         dword ptr [ebp-10h],eax
00401666   mov         ecx,dword ptr [constpi+4 (0047002c)]
0040166C   mov         dword ptr [ebp-0Ch],ecx

53:       double pd = 3.141592653589793238462643383279502884197;
0040166F   mov         dword ptr [ebp-18h],54442D18h
00401676   mov         dword ptr [ebp-14h],400921FBh

54:       double p = pi;
0040167D   mov         ecx,offset pi (00470022)
00401682   call        @ILT+260(boost::math::constant<boost::math::pi_tag,double>::operator double) (00401109)
00401687   fstp        qword ptr [ebp-20h]


70:       template<> inline constant<pi_tag, double>::operator double() const
71:       {
00401990   push        ebp
00401991   mov         ebp,esp
00401993   sub         esp,44h
00401996   push        ebx
00401997   push        esi
00401998   push        edi
00401999   push        ecx
0040199A   lea         edi,[ebp-44h]
0040199D   mov         ecx,11h
004019A2   mov         eax,0CCCCCCCCh
004019A7   rep stos    dword ptr [edi]
004019A9   pop         ecx
004019AA   mov         dword ptr [ebp-4],ecx
72:         return 3.141592653589793238462643383279502884197;
004019AD   fld         qword ptr [__real@8@4000c90fdaa22168c000 (00470110)]
73:       }
004019B3   pop         edi
004019B4   pop         esi
004019B5   pop         ebx
004019B6   mov         esp,ebp
004019B8   pop         ebp
004019B9   ret
--- No source file  ------------------------------------------------------------------------------------------------------------------
004019BA   int         3
004019BB   int         3
004019BC   int         3
004019BD   int         3
			
*/