// gamma_function_constant.hpp

namespace boost
{
  namespace math
  {
    // gamma
		struct gamma_tag {}; // Identifies constant as gamma.

    template<> inline constant<float, gamma_tag >::operator float() const
    {
      return 0.5772156649015328606065120900824024310421593359399235988F;
    } 
    template<> inline constant< double, gamma_tag>::operator double() const
    {
      return 0.5772156649015328606065120900824024310421593359399235988;
    }
    template<> inline constant< long double, gamma_tag >::operator long double() const
    {
      return 0.5772156649015328606065120900824024310421593359399235988L;
    }

    namespace float_constants
    {
      constant<float, gamma_tag > const gamma;
    }
    namespace double_constants
    {
      constant<double, gamma_tag > const gamma; 
    }
    namespace long_double_constants
    {
      constant<long double, gamma_tag > const gamma;
    }

  }// namespace math
} // namespace boost
 
