#ifndef HPP_FUNCTION_CONSTANTS
#define HPP_FUNCTION_CONSTANTS

// Based on a post by Michael Kenniston:  http://groups.yahoo.com/group/boost/message/14867
// Written by J:\Cpp\WinNTL-5_0c\NTL5\makeConstants\makeConstants.cpp Tue Oct 16 15:40:55 2001
// Version 1.1
// Using Victor Shoup's NTL version 5.0c (www.shoup.net/ntl)

// Copyright Paul A Bristow, hetp Chromatography, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

// C++ floating-point types accurate to 40 decimal digits.

// For documentation and sources see math_constants.htm

// This file is a collection of some basic mathematical constants.

// The objective is to achieve the full accuracy possible
// with IEC559/IEEE745 Floating point hardware and C++ language.
// This has no extra cost to the user, but reduces irritating effects
// caused by the inevitable limitations of floating point calculations.
// At least these manifest as spurious least significant digits,
// at worst algorithms that fail because comparisons fail.
// 40 decimal places ensures no loss of accuracy
// even for 128-bit significand floating-point.

namespace boost
{
  namespace math
	{ // Sub-space for math - provisional.
		template< typename Representation, typename Tag >
		struct constant
		{ // The "constant" class/struct provides a place to put
      // the actual definition of the value of each constant.
			// It also turns an implicit conversion operation
			// (which does not need any parentheses) into an explicit call to the
			// correct function that actually knows (and returns) the right value.
			public:
			// constant(){} // Unclear if this constructor is required or not.
			// Avoid contructor here (if compiler and options allow)
			// to prevent unused constants creating unwanted constructor.
			// Not all compilers and/or linkers optimise these out.
			operator Representation() const;
			// operator () returns the value of the constant.
      // Fully specialized for each Representation and Tag pair.
			// Representation may be:
			//   operator float() const,
			//   operator double() const, or
			//   operator long double () const,
			// or other user-defined floating-point type.
		}; // template< typename Representation, typename Tag >	class constant

		struct pi_tag {}; // Identifies constant as pi.

		// Specializations for three builtin floating-point types:
		// Note correct suffix F or L is required.
		template<> inline constant< float, pi_tag >::operator float() const
		{ 
			return 3.141592653589793238462643383279502884197F;
		}
		
		template<> inline constant< double, pi_tag >::operator double() const
		{
			return 3.141592653589793238462643383279502884197;
		}
		
		template<> inline constant< long double, pi_tag >::operator long double() const
		{
			return 3.141592653589793238462643383279502884197L;
		}
		// Could add specializations for other representations.

		
		// constant::constant< double, pi_tag >() {} // requires argument list.
		// so not used.

		// Define constant is namespaces to hold three builtin floating-point representations.
		namespace float_constants
		{
			constant< float, pi_tag > const pi;
		}		
		namespace double_constants
		{
			constant< double, pi_tag > const pi;
		}
		namespace long_double_constants
		{
			constant< long double, pi_tag > const pi;
		}
		// Could add other namespace(s) for user defined representation(s). 

  } // namespace math
} // namespace boost

// Similarly for other constants.

namespace boost
{
  namespace math
  {
    // sqrt2
		struct sqrt2_tag {}; // Identifies constant as sqrt2.

    template<> inline constant<float, sqrt2_tag >::operator float() const
    {
      return 1.41421356237309504880168872420969807857F;
    } 
    template<> inline constant< double, sqrt2_tag>::operator double() const
    {
      return 1.41421356237309504880168872420969807857;
    }
    template<> inline constant< long double, sqrt2_tag >::operator long double() const
    {
      return 1.41421356237309504880168872420969807857L;
    }

    namespace float_constants
    {
      constant<float, sqrt2_tag > const sqrt2;
    }
    namespace double_constants
    {
      constant<double, sqrt2_tag > const sqrt2; 
    }
    namespace long_double_constants
    {
      constant<long double, sqrt2_tag > const sqrt2;
    }

		// e
    struct e_tag {};
    template<> inline constant< long double, e_tag>::operator long double() const
    {
      return 2.7182818284590452353602874713526624977572L;
    }
    template<> inline constant<double, e_tag >::operator double() const
    {
      return 2.7182818284590452353602874713526624977572;
    }
    template<> inline constant<float, e_tag >::operator float() const
    {
      return 2.7182818284590452353602874713526624977572F;
    } 

    namespace float_constants
    {
      constant<float, e_tag > const e;
    }
    namespace double_constants
    {
      constant<double, e_tag > const e; 
    }
    namespace long_double_constants
    {
      constant< long double, e_tag> const e;
    }
  }// namespace math
} // namespace boost

/*

*/

#endif
// End of function_constants.hpp 
