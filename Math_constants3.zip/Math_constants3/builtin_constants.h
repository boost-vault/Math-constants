// builtin_constants.h

// Example header to get X86 builtin constant pi.

// Highest accuracy if using extended precision,
// but probably less portable, so NOT used by BOOST math_constants.


template<class T>
struct mathconst
{
  static const T pi() {
    long double x;
		// Assembler insert to get floating point constants.
		// Using Intel X86 Floating Point.
		#if (_MSC_VER >1000)
		// Compiling with Microsoft Visual Studio.
			__asm
			{
				fldpi
				fstp x
			}
		#endif // _MSC_VER
		// Compiling with Linux gcc
		#ifdef __GNUC__
			__asm__("fldpi" : "=t" (x));
	// Other constants, like e could be added.
//#endif

    return x;
  }
};


/* (C) Copyright Paul A Bristow, hetp Chromatography, 2001
 Permission to copy, use, modify, sell and distribute this software
 is granted provided this copyright notice appears in all copies.
 This software is provided "as is" with express or implied warranty,
 and with no claim as to its suitability for any purpose.*/

