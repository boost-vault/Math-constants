//  foo.cpp

// This file only exists to make sure there is more than one
// compilation unit that uses a single constant - 
// thus testing the extern definition.

#include "pi_constant.hpp"

using namespace boost::math;

double foo()
{
	return real_cast< double >( pi );
}
