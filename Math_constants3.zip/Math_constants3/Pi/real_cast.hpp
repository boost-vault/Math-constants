//  real_cast.hpp

// Copyright (c) 2002 by Michael S. Kenniston & Paul A Bristow.
// Permission to copy, modify, and use this code is granted
// without fee, so long as this notice remains in all copies
// of the source code.  This code is provided "as-is" without
// implied or express warranty of any kind.

#ifndef REAL_CAST_HPP
#define REAL_CAST_HPP

#if defined(_MSC_VER ) && ! defined( __COMO_VERSION__ )
// Borland, gnu, CodeWarrior, and Comeau seem OK with this code.
// MSVC6 & 7 need a work-around for the template operator function.
// Other compilers I have not tested.
#define BOOST_REAL_BROKEN
#endif

namespace boost
{
	namespace math
	{
		// The "real_cast" function is invoked by users to convert an
		// math constant to a concrete representation.
		// Its only purpose is to convert a simple, familiar syntax, like pi,
		// into a call to the ugly underlying overloaded
		// "constant_value()" function, like pi().

		template< typename Target, typename realType >
			inline Target real_cast( const realType & real, const Target * target = 0 )
		{
			return constant_value( target, real );
		}

		// The "real_type" class is specialized for each constant.
		// Objects of this type contain no actual runtime data:
		// the type itself represents the constant.

		template< typename Tag >
		struct real_type
		{
#ifndef BOOST_REAL_BROKEN
			// MSVC 6 & 7 work-around for the template operator function.
			template< typename Target >
				inline operator Target() const { return constant_value( static_cast< Target * >( 0 ), *this ); }
#else
			// All other compilers.
			inline operator float() const { return constant_value( static_cast< float * >( 0 ), *this ); }
			inline operator double() const { return constant_value( static_cast< double * >( 0 ), *this ); }
			inline operator long double() const { return constant_value( static_cast< long double * >( 0 ), *this ); }
#endif
		};

		// Define convenience macros to make life easier for people adding their own constants.
		// See example of pi which is written out by hand in pi_constant.hpp.
		// Usage example:
		//   BOOST_REAL_CONSTANT( pi, 3.1, 3.142, 3.14159 ); // Precision very reduced for demo only!
		// struct name##_tag; may suffice since constructor is never used?
		// struct name##_tag {}; seems to be required by some compilers (not MSVC 6 or 7.0), for reasons unclear.
#define BOOST_REAL_CONSTANT( name, \
	float_value, double_value, long_double_value ) \
		struct name##_tag ; \
		typedef real_type< name##_tag > name##_t; \
		extern name##_t name; \
		inline float constant_value( const float *, const name##_t & ) { return float_value##F; } \
		inline double constant_value( const double *, const name##_t & ) { return double_value; } \
		inline long double constant_value( const long double *, const name##_t & ) { return long_double_value##L; }

		// Define shortcuts for all eight arithmetic operations.
		// This eliminates the need for most explicit calls to "real_cast".

		template< typename Target, typename Tag >
			inline Target operator+( const Target & lhs, const real_type< Tag > & rhs )
		{ // For example: 2.F + pi
			return lhs + real_cast< Target >( rhs );
		}

		template< typename Target, typename Tag >
			inline Target operator+( const real_type< Tag > & lhs, const Target & rhs )
		{ // For example: pi + 2.F
			return real_cast< Target >( lhs ) + rhs;
		}

		template< typename Target, typename Tag >
			inline Target operator-( const Target & lhs, const real_type< Tag > & rhs )
		{
			return lhs - real_cast< Target >( rhs );
		}

		template< typename Target, typename Tag >
			inline Target operator-( const real_type< Tag > & lhs, const Target & rhs )
		{
			return real_cast< Target >( lhs ) - rhs;
		}

		template< typename Target, typename Tag >
			inline Target operator*( const Target & lhs, const real_type< Tag > & rhs )
		{
			return lhs * real_cast< Target> ( rhs );
		}

		template< typename Target, typename Tag >
			inline Target operator*( const real_type< Tag > & lhs, const Target & rhs )
		{
			return real_cast< Target >( lhs ) * rhs;
		}

		template< typename Target, typename Tag >
			inline Target operator/( const Target & lhs, const real_type< Tag > & rhs )
		{
			return lhs / real_cast< Target >( rhs );
		}

		template< typename Target, typename Tag >
			inline Target operator/( const real_type< Tag > & lhs, const Target & rhs )
		{
			return real_cast< Target >( lhs ) / rhs;
		}

	} // namespace math
} // namespace boost

#endif // REAL_CAST_HPP
