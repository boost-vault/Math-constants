//  pi_constant.cpp
//

// Copyright (c) 2002 by Michael S. Kenniston & Paul A Bristow.
// Permission to copy, modify, and use this code is granted
// without fee, so long as this notice remains in all copies
// of the source code.  This code is provided "as-is" without
// implied or express warranty of any kind.

#include "pi_constant.hpp"

namespace boost
{
	namespace math
	{ // Define the tags and names used for constants.
		pi_t pi; // Defines the name used for constant pi.
		// ... other constants
	} // namespace math
} // namespace boost
