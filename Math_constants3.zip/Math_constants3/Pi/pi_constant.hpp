// pi_constant.hpp

// Copyright (c) 2002 by Michael S. Kenniston & Paul A Bristow
// Permission to copy, modify, and use this code is granted
// without fee, so long as this notice remains in all copies
// of the source code.  This code is provided "as-is"
// without implied or express warranty of any kind.

#ifndef PI_CONSTANT_HPP
#define PI_CONSTANT_HPP

#include "real_cast.hpp"

namespace boost
{
	namespace math
	{	// For this demonstration only, precision of float, double and long double
		// pi are SERIOUSLY reduced to 3.1F, 3.141 & 3.14159L,
		// so different values are obvious without zillions of decimal digits.

		// "pi" is expanded manually below instead of using a MACRO,
		// so you can see what's going on more easily.

		//	struct pi_tag {}; // Null constructor required by some compilers.
		struct pi_tag; // Also compiles for MSVC 6 & 7  - uses compiler written constructor?
		//  struct pi_tag; may suffice since constructor is never used.
		// ISO standard is not clear if (or why) an explicit constructor is needed.

		typedef real_type< pi_tag > pi_t;

		extern pi_t pi; // Defined in pi_constants.cpp
		// foo.cpp exists solely to test this extern definition of pi.

		inline float constant_value( const float *, const pi_t & )
		{ // Actual constant value.
			// Note: ends with F to ensure correct float type.
			return 3.1F; // Simulating VERY low precision pi as float.
		}

		inline double constant_value( const double *, const pi_t & )
		{
			// Note: ends with just digit to ensure correct double type.
			return 3.141; // Simulating moderate precision pi as double.
		}

		inline long double constant_value( const long double *, const pi_t & )
		{
			// Note: ends with L to ensure correct long double type.
			return 3.14159L; // Simulating highER precision pi as long double.
		}

		// BOOST_REAL_CONSTANT( pi, 3.1, 3.142, 3.14159 ); has same effect as above code.

		// All constants will be defined at full 40 decimal digit precision, for example:
		// BOOST_REAL_CONSTANT( pi, 3.14159265358979323846264338327950288, 3.14159265358979323846264338327950288,  3.14159265358979323846264338327950288);
		// BOOST_REAL_CONSTANT( e, 2.7182818284590452353602874713526625, 2.7182818284590452353602874713526625, 2.7182818284590452353602874713526625);
		// ... for many other constants.
	} // namespace math
} // namespace boost

#endif // PI_CONSTANT_HPP

