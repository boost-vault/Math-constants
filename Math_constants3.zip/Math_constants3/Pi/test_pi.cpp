// test_pi.cpp

// Copyright (c) 2002 by Michael S. Kenniston & Paul A Bristow
// Permission to copy, modify, and use this code is granted
// without fee, so long as this notice remains in all copies
// of the source code.  This code is provided "as-is" without
// implied or express warranty of any kind.

#include <iostream>

#include "pi_constant.hpp"
// #include "real_cast.hpp"

using std::cout;
using std::endl;

using namespace boost::math;

int main()
{
#if defined(__FILE__) && defined(__TIMESTAMP__)
	cout << __FILE__ << ' ' << __TIMESTAMP__ << endl;
#endif
	// Some very simple examples:
	// Note that the precision of pi is seriously reduced to make it
	// obvious whether result is float 3.1F, double 3.141, or long double  3.14159L.
	// This is only for this demo of course!!!

	{ // Declare factor and result are float, so implicit use of pi invokes a float, and result is float.
		float radius = 1.; // Unity so precision of result is obvious.
		float area = pi * radius * radius;
		cout << "float area = pi * radius * radius is " << area << endl;
		// result is 3.1 so pi is a float.
	}
  { // Now change to use double, so implicit use of pi invokes a double, and result is double.
		double radius = 1.;
		double area = pi * radius * radius;
		cout << "double area = pi * radius * radius is " << area << endl;
		// result is 3.141 so pi is now a double. Magic!
	}
  { // Now change to use long double, so implicit use of pi invokes a long double, and result is long double.
		long double radius = 1.;
		long double area = pi * radius * radius;
		cout << "long double area = pi * radius * radius is " << area << endl;
		// result is 3.14159 so pi is now a double. More Magic!
	}
		// But there are some possible surprises!!!
	{ // Change to use float radius and a double area.
		float radius = 1.;
		double area = pi * radius * radius;
		cout << "Using float radius, double area = pi * radius * radius is " << area << endl;
		// Result is 3.1 so pi is now float.
		// Definition of operator* means that result of pi * radius is FLOAT,
		// despite area being a double!
		// Snare for the unwary?
	}
	{ // Now change to use a double radius and a float area.
		double radius = 1.; // Definition of operator* means that result is double.
		// If we write:
		// float area = pi * radius * radius;
		// then get the expected warning:
		// "C4244: 'initializing' : conversion from 'double' to 'float', possible loss of data."
		// Or if we write:
		float area = static_cast<float>(pi * radius * radius); // Avoids warning!
		cout << "float area = static_cast<float>(pi * radius * radius) is " << area << endl;
		// result is 3.141 so pi is now appears to be double precision. 
		// But if precision of constant corresponded to true precision of float,
		// it would have been reduced back to float precision? Or nearly??
	}
	{
		// Examples of explicit namespace resolution:
		cout << "boost::math::real_cast<float>(pi) is " << boost::math::real_cast<float>(pi) << endl; 
		cout << "boost::math::real_cast<double>(pi) is " << boost::math::real_cast<double>(pi) << endl; 
		cout << "boost::math::real_cast<long double>(pi) is " << boost::math::real_cast<long double>(pi) << endl; 
	}
	{  // If want three C style constants, we could write:
		float pi_f = boost::math::real_cast<float>(pi);
		double pi_d = boost::math::real_cast<double>(pi);
		long double pi_l = boost::math::real_cast<long double>(pi);
		// and use them for example thus:
		cout << "float pi_f  is " << pi_f << endl;
		cout << "double pi_d  is " << pi_d << endl; // pi_d NOT pi - see below.
		cout << "long double pi_l  is " << pi_l << endl;
		// But we cannot write:
		// cout << "pi  is " << pi << endl;
		// "error C2593: 'operator <<' is ambiguous"

		// Check that pi really is const.
		// pi = 3.; // Naughty! (Only politicians are allowed to do this!)
		// But it is correctly caught by the compiler:
		// "error C2679: binary '=' : no operator defined which takes a right-hand operand of type 'const double' "
		// boost::math::real_cast<float>(pi) = 3.; // Also naughty! "error C2106: '=' : left operand must be l-value"
	}
   return 0;
} // main

/* Output is:

test_pi.cpp Thu Jul  4 12:32:10 2002
float area = pi * radius * radius is 3.1
double area = pi * radius * radius is 3.141
long double area = pi * radius * radius is 3.14159
Using float radius, double area = pi * radius * radius is 3.1
float area = static_cast<float>(pi * radius * radius) is 3.141
boost::math::real_cast<float>(pi) is 3.1
boost::math::real_cast<double>(pi) is 3.141
boost::math::real_cast<long double>(pi) is 3.14159
float pi_f  is 3.1
double pi_d  is 3.141
long double pi_l  is 3.14159
Press any key to continue

*/


