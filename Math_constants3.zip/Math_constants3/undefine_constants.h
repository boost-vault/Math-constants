#ifndef H_UNDEFINE_CONSTANTS
#define H_UNDEFINE_CONSTANTS

/*
// Written by J:\Cpp\WinNTL-5_0c\NTL5\makeConstants\makeConstants.cpp Tue Oct 16 15:40:55 2001
// Version 1.0
// Using Victor Shoup's NTL version 5.0c (www.shoup.net/ntl)

// (C) Copyright Paul A Bristow, hetp Chromatography, 2001, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

// This file contains #UNDEF statements matching define_constants.h.
// useful to minimise namespace pollution (especially global namespace).
*/

#undef BOOST_PI /* pi */
#undef BOOST_SQRT2 /* sqrt(2) */
#undef BOOST_E /* Euler e */

#endif
/* End of UNdefine_constants.h */
