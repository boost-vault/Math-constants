// testDoubleConstants.cpp

/*
// (C) Copyright Paul A Bristow, hetp Chromatography, 2001
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.
*/
// testDefineConstants.cpp

#include <iostream>
#include <iomanip>

#include "define_constants.h"

using std::cout;
using std::cerr;
using std::endl;

const char nl = '\n';
const char tab = '\t';
const char space = ' ';

int main()
{
	cout << "Test " << __FILE__ << space << __TIMESTAMP__ << endl;
	cout.precision(18);
	cout << "MACRO pi = " << BOOST_PI << endl;
	return 0;
}  // main

/*

	output:

Test j:\cpp\winntl-5_0c\ntl5\testdefineconstants\testdefineconstants.cpp Tue Oct
16 15:31:01 2001
MACRO pi = 3.1415926535897931
Press any key to continue

	*/