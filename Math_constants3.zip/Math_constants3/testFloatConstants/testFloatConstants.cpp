// testFloatConstants.cpp

// (C) Copyright Paul A Bristow, hetp Chromatography, 2001
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <iostream>
#include <limits>

#include "\Cpp\WinNTL-5_0c\NTL5\makeConstants\float_constants.hpp"

using std::cout;
using std::endl;

double const log10Two = 0.30102999566398119521373889472449; // log10(2.))

int main()
{
	cout << "Test " << __FILE__ << ' ' << __TIMESTAMP__ << endl;

	cout.precision(std::numeric_limits<float>::digits10);
	cout <<"float pi = " << pi << " to " << std::numeric_limits<float>::digits10 << " decimal digits." << endl;

	int significant_float_decimal_digits = // Number of significant decimal digits for float.
		int(ceil(1 + std::numeric_limits<float>::digits * log10Two));
	cout.precision(significant_float_decimal_digits);
	cout <<"float pi = " << pi << " to " << significant_float_decimal_digits <<  " decimal digits." << endl;
	int significant_double_decimal_digits = // Number of significant decimal digits for double
	int(ceil(1 + std::numeric_limits<double>::digits * log10Two));
	cout.precision(significant_double_decimal_digits);
	cout <<"double pi = " << pi  << " to " << significant_double_decimal_digits << " decimal digits."<< endl;

	return 0;
}  // main


/*

	Output:

Test testFloatConstants.cpp Thu Dec 12 22:09:33 2002

float pi = 3.14159 to 6 decimal digits.
float pi = 3.14159274 to 9 decimal digits.
double pi = 3.1415927410125732 to 17 decimal digits.

Press any key to continue

	*/