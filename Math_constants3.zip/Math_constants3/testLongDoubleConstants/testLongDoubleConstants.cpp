// testLongDoubleConstants.cpp

// (C) Copyright Paul A Bristow, hetp Chromatography, 2001
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <iostream>
#include <limits>

#include "\Cpp\WinNTL-5_0c\NTL5\makeConstants\long_constants.hpp"

using std::cout;
using std::endl;

const char nl = '\n';
const char space = ' ';

int main()
{
	cout << "Test " << __FILE__ << space << __TIMESTAMP__ << endl;
	cout.precision(std::numeric_limits<long double>::digits10 +2);
	// ensure all significant digits are shown.
	cout <<"long double pi = " << pi << endl;

	return 0;
}  // main


/*

	Output:

Test J:\Cpp\WinNTL-5_0c\NTL5\testLongDoubleConstants\testLongDoubleConstants.cpp
Tue Oct 16 15:38:35 2001
long double pi = 3.1415926535897931
Press any key to continue


	*/