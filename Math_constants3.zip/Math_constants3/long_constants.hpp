
#ifndef HPP_LONG_CONSTANTS
#define HPP_LONG_CONSTANTS

// Written by J:\Cpp\WinNTL-5_0c\NTL5\makeConstants\makeConstants.cpp Tue Oct 16 15:40:55 2001
// Version 1.01
// Using Victor Shoup's NTL version 5.0c (www.shoup.net/ntl)

//(C) Copyright Paul A Bristow, hetp Chromatography, 2001, 2002;
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

// C++ Floating point type is long double accurate to 40 decimal digits.

// For documentation & sources see constants.htm

// This file is a collection of the most basic mathematical constants.

// The objective is to achieve the full accuracy possible
// with IEC559/IEEE745 Floating point hardware and C++ language.
// This has no extra cost to the user, but reduces irritating effects
// caused by the inevitable limitations of floating point calculations.
// At least these manifest as spurious least significant digits,
// at worst algorithms that fail because comparisons fail.
// 40 decimal places ensures no loss of accuracy even for 128-bit floating point.

// Note: MSVC++ 6 implements long double as double, IEEE 64-bit real format.
// Linux/gcc can optionally use 80-bit for long double,
// Sparc can use 128-bit for long double.

const long double pi = 3.141592653589793238462643383279502884197L; // pi
const long double sqrt2 = 1.41421356237309504880168872420969807857L; // sqrt(2)
const long double e = 0.5772156649015328606065120900824024310422L; // Euler e

#endif
// End of long_constants.hpp
