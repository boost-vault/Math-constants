// test pi_interval

#include <iostream>
#include <iomanip>
#include <limits>

using std::cout;
using std::cin;
using std::endl;
using std::dec;
using std::hex;
using std::right;
using std::boolalpha;
using std::string;
using std::setprecision;
using std::setw;

const char nl = '\n';
const char tab = '\t';
const char space = ' ';

void outAsHex(double);  // Display double as normal and as Hex.
void outAsHex(float d); // Display float as normal and as Hex.

union dhex
{
	double d;
	unsigned short usa[4];  // Suits Intel 8087 FP Plauger C Standard p 67.
};

union fhex
{
	float f;  // 32 bit real
	unsigned long l;  // 32 bit long.
};


template<typename FPType>
const FPType pi_lower()
{
	int digits = std::numeric_limits<FPType>::digits;
	int radix = std::numeric_limits<FPType>::radix;

	FPType lower =
		(radix == 2) ?
		(
		(digits >= 64) ?  3.14159265358979323829596852490908531763125210004425048828125L : // value for 64 bits.
		(digits >= 53) ?  3.141592653589793115997963468544185161590576171875 : // value for 53 bits.
		(digits >= 24) ?  3.141592502593994140625F : // value for 24 bits.
		3)
			: std::numeric_limits<FPType>::quiet_NaN(); // unknown and/or unimplemented floating point format!
	return lower;
} // template<type FPType> const FPType lower()



int main()
{
	cout << "Test " << __FILE__ << space << __TIMESTAMP__ << endl;

	cout.precision(9); // significant digits10

	static const float pi_f = 3.14159265358979323846264338327950288419716939937510f;
	static const double pi_d = 3.14159265358979323846264338327950288419716939937510;
	static const long double pi_l = 3.14159265358979323846264338327950288419716939937510L;
	cout << "pi == " << pi_f << endl;

	// static const float pi_f_l = 13176794.0f/(1 << 22);
	// static const float pi_f_u = 13176795.0f/ (1 << 22);

	// Exactly representable values calculated using NTL.
	static const float pi_f_l = 3.141592502593994140625F;
	static const float pi_f_u = 3.1415927410125732421875F;

	cout << "pi_f_l  = " << pi_f_l << endl;
	cout << "pi_f_u  = " << pi_f_u << endl;

	if (pi_f_l == pi_f)
	{
		cout << "pi_f_l == pi_f" << endl;
	}
	if (pi_f_u == pi_f)
	{
		cout << "pi_f_u_f == pi_f " << endl;
	}

	if (!(pi_f_l == pi_f) && !(pi_f_u == pi_f))
	{
    std::cerr << "WARNING : constant is neither lower nor upper limit!" << std::endl;
	}
	float lp = pi_f_l + pi_f_u; // lower + upper
  if ((lp < float(2) * pi_f_u) && (lp > float(2) * pi_f_l))
	{
    std::cerr << "WARNING : more precise interval possible!" << std::endl;
	}

	cout << "pi_f_l = "; outAsHex(pi_f_l); cout << endl;
	cout << "pi_f_u = "; outAsHex(pi_f_u); cout << endl;
	cout << "pi_f = ";   outAsHex(pi_f); cout << endl;

	// Some further values to prove that IN-significant digits really are,
	// BUT on other compilers, C++ Specification says that they might not be!
	// Correct rounding is NOT required.  So this test is misleading.

	static const float pi_f_l3 = 3.141592509999999f;
	static const float pi_f_u3 = 3.141592740000000f;
	cout << "pi_f_l3 = " << pi_f_l3 << endl;
	cout << "pi_f_u3 = " << pi_f_u3 << endl;
	if (pi_f_l == pi_f_l3)
	{
		cout << "pi_f_l == pi_f_l3 " << endl;
	}
	if (pi_f_u == pi_f_u3)
	{
		cout << "pi_f_u == pi_f_u3 " << endl;
	}

	if (pi_f_l == pi_f)
	{
		cout << "pi_f_l == pi_f" << endl;
	}
	if (pi_f_u == pi_f)
	{
		cout << "pi_f_u == pi_f " << endl;
	}


	// double

	cout.precision(17); // significant digits10

	// compiler chokes divide by zero
	// static const double pi_d_u = 3537118876014221.0f/(1 << 51);
	// cout << "pi_d_l = " << pi_d_l << endl;
	// cout << "pi_d_u = " << pi_d_u << endl;
	//static const double pi_d_l = 3.141592653589793115997963468544185161590576171875;
	//static const double pi_d_u = 3.14159265358979400417638316866941750049591064453125;

	static const double pi_d_l = 3.141592653589793115997963468544185161590576171875;
	static const double pi_d_u = 3.141592653589793560087173318606801331043243408203125;
	cout << "pi_d = " << pi_d << endl;
	cout << "pi_d_l = " << pi_d_l << endl; // pi_d_l = 3.1415926535897931
	cout << "pi_d_u = " << pi_d_u << endl; // pi_d_u = 3.141592653589794

	if (pi_d_l == pi_d)
	{
		cout << "pi_d_l == pi_d" << endl;
	}
	if (pi_d_u == pi_d)
	{
		cout << "pi_d_u == pi_d " << endl;
	}

	// Expect one of the other to match pi_d

	cout << "pi_d_l = "; outAsHex(pi_d_l); cout << endl;	// 0x400921fb54442d18
	cout << "pi_d_u = "; outAsHex(pi_d_u); cout << endl;	// 0x400921fb54442d19
	cout << "pi_d = ";   outAsHex(pi_d); cout << endl;  	// 0x400921fb54442d18

	// Long double 64 bit significand values
	cout.precision(21); // significant digits10

//static const long double pi_l_l = 7244019458077122842.0f/(1 << 62)
//static const long double pi_l_u = 7244019458077122843.0f/(1 << 62);
	// Compiler will choke!
	static const long double pi_l_l = 3.14159265358979323829596852490908531763125210004425048828125L;
	static const long double pi_l_u = 3.141592653589793238729649393903287091234233203524017333984375L;

	cout << "pi_l_l = " << pi_l_l << endl; // 3.1415926535897931
	cout << "pi_l_u = " << pi_l_u << endl; // 3.1415926535897931
	// MSVC long double unable to distinguish!

	if (pi_l_l == pi_l)
	{
		cout << "pi_l_l == pi_l" << endl;
	}
	if (pi_l_u == pi_l)
	{
		cout << "pi_l_u == pi_l " << endl;
	}
	cout << "pi_d_l = "; outAsHex(pi_d_l); cout << endl;
	cout << "pi_d_u = "; outAsHex(pi_d_u); cout << endl;
	cout << "pi_d = ";   outAsHex(pi_d); cout << endl;

	// const float pi_l_f == pi_lower<float>();
	cout << "pi_lower " <<  pi_lower<float>()<< endl;

	return 0;
}  // main


void outAsHex(float d)
{
	fhex fd = {d};  // Initialise float fd.d = 0.0;
	cout << fd.f << " == 0x" << hex << fd.l << endl;
}  // displayAsHex


void outAsHex(double d)
{
	dhex dd = {d};  // Initialise double dd.d = 0.0;
	// Assume Intel 8087 FP - not sure this is right?
	// Plaguer p 67
	cout.fill('0');
	cout << dd.d << " == 0x" << hex << right
		<< setw(4) << dd.usa[3] // SCCC CCCC CCCC FFFF  sign & exponent.
		<< setw(4) << dd.usa[2] // CCCC
		<< setw(4) << dd.usa[1] // CCCC
		<< setw(4) << dd.usa[0] // FFFF
		<< endl;

}  // displayAsHex

void outAsHex(long double d)
{ // For MSVC double and long double are exactly the same.
	dhex dd = {d};  // Initialise double dd.d = 0.0;
	// Assume Intel 8087 FP - not sure this is right?
	// Plaguer p 67
	cout.fill('0');
	cout << dd.d << " == " << hex   << right
		<< setw(4) << dd.usa[3] // SCCC CCCC CCCC FFFF  sign & exponent.
		<< ' ' << setw(4) << dd.usa[2] // CCCC
		<< ' ' << setw(4) << dd.usa[1] // CCCC
		<< ' ' << setw(4) << dd.usa[0] // FFFF
		<< endl;

}  // displayAsHex
/*


Test j:\cpp\winntl-5_0c\ntl5\test_pi_interval\test_pi_interval.cpp Thu Sep  5 16:
50:05 2002
pi == 3.14159274
pi_f_l  = 3.1415925
pi_f_u  = 3.14159274
pi_f_l2 = 3.1415925
pi_f_u2 = 3.14159274
pi_f_l == pi_f_l2
pi_f_u == pi_f_u2
pi_f_u == pi
Press any key to continue


Test j:\cpp\winntl-5_0c\ntl5\test_pi_interval\test_pi_interval.cpp Fri Sep  6 10:
54:38 2002
pi == 3.14159274
pi_f_l  = 3.1415925
pi_f_u  = 3.14159274
pi_f_l2 = 3.1415925
pi_f_u2 = 3.14159274
pi_f_l == pi_f_l2
pi_f_u == pi_f_u2
pi_f_u == pi
pi_f_l3 = 3.1415925
pi_f_u3 = 3.14159274
pi_f_l == pi_f_l3
pi_f_u == pi_f_u3
pi_f_u == pi
pi_f_l4 = 3.1415925
pi_f_u4 = 3.14159274
pi_f_l == pi_f_l4
pi_f_u == pi_f_u4
pi_f_u == pi
Press any key to continue

pi_d_u = 3.141592653589794



Test j:\cpp\winntl-5_0c\ntl5\test_pi_interval\test_pi_interval.cpp Thu Oct  3 15:
16:57 2002
pi == 3.14159274
pi_f_l  = 3.1415925
pi_f_u  = 3.14159274
pi_f_l2 = 3.1415925
pi_f_u2 = 3.14159274
pi_f_l == pi_f_l2
pi_f_u == pi_f_u2
pi_f_u_f == pi_f
pi_f_l = 3.1415925 == 0x40490fda

pi_f_u = 3.14159274 == 0x40490fdb

pi_f = 3.14159274 == 0x40490fdb

pi_f_l3 = 3.1415925
pi_f_u3 = 3.14159274
pi_f_l == pi_f_l3
pi_f_u == pi_f_u3
pi_f_u == pi_f
pi_f_l4 = 3.1415925
pi_f_u4 = 3.14159274
pi_f_l == pi_f_l4
pi_f_u == pi_f_u4
pi_f_u == pi_f
pi_d = 3.1415926535897931
pi_d_l = 3.1415926535897931
pi_d_u = 3.1415926535897936
pi_d_l == pi_d
pi_d_l = 3.1415926535897931 == 0x400921fb54442d18

pi_d_u = 3.1415926535897936 == 0x400921fb54442d19

pi_d = 3.1415926535897931 == 0x400921fb54442d18

pi_l_l = 3.1415926535897931
pi_l_u = 3.1415926535897931
pi_l_l == pi_l
pi_l_u == pi_l
pi_d_l = 3.1415926535897931 == 0x400921fb54442d18

pi_d_u = 3.1415926535897936 == 0x400921fb54442d19

pi_d = 3.1415926535897931 == 0x400921fb54442d18

Press any key to continue






*/