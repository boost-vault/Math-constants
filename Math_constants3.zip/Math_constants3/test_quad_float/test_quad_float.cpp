// Demo of quad_float and attempt to create interval values.
// Ran NTL provided test OK.

#include <iostream>
#include <iomanip>
#include <cassert>
#include <cfloat> // for DBL_EPS etc
#include <cmath> // for frexp
#include <limits> // for numeric limits.
#include <sstream>
#include <string>

#include <NTL/version.h>
#include <NTL/quad_float.h>

//#include <NTL/RR.h> // arbitrary floating point precision, use 150 bit ~50 decimal digits_f.
//#include <NTL/ZZ.h> // arbitrary precision 'big' integer.

NTL_CLIENT

using NTL::quad_float;

using std::cout;
using std::endl;
using std::stringstream;

const char nl = '\n';
const char sp = ' ';
const char tab = '\t';

bool diag = false;

void outAsHex(float); // Display float as normal and as hex.
void outAsHex(double);  // Display double as normal and as hex.
void outAsHex(long double);  // Display double as normal and as hex.

union fhex
{ // Used by void outAsHex(float)
	float f;  // 32 bit real
	unsigned long l;  // 32 bit long.
};

union dhex
{ // Used by void outAsHex(double)
	double d;
	unsigned short usa[4];  // Suits Intel 8087 FP P J Plauger C Standard p 67.
};

/*
105 significand
static const long double pi   = 3.14159265358979323846264338327950288419716940075302929584103285579371202800448997465293046115320802958337L;
static const long double pi_l = 3.1415926535897932384626433832794319232571146478579031130162172065489745165223212097771465778350830078125L;
static const long double pi_u = 3.141592653589793238462643383279530530870267274333579579086877554827683667326709837652742862701416015625L;
106
static const long double pi   = 3.141592653589793238462643383279502884197169400753029295841032855793712028004489974652930461153208029583374L;
static const long double pi_l = 3.14159265358979323846264338327948122706369096109574134605154738068832909192451552371494472026824951171875L;
static const long double pi_u = 3.141592653589793238462643383279530530870267274333579579086877554827683667326709837652742862701416015625L;
107
static const long double pi   = 3.1415926535897932384626433832795028841971694007530292958410328557937120280044899746529304611532080295833742L;
static const long double pi_l = 3.14159265358979323846264338327948122706369096109574134605154738068832909192451552371494472026824951171875L;
static const long double pi_u = 3.141592653589793238462643383279505878966979117714660462569212467758006379625612680683843791484832763671875L;
																															 */

void check(quad_float l,quad_float m, quad_float h);

int main()
{

	cout << "Math constants intervals " << __FILE__ << ' ' <<  __TIMESTAMP__  << "\n"; 
	cout << "NTL version " << NTL_VERSION << ' '<< ", Compiled with MSVC++ version " << _MSC_VER << endl;

	int quad_float_significant_digits =  2 + 105 * 30101/100000; // 33
	cout << "quad_float_significant_digits " << quad_float_significant_digits << endl;
	quad_float::SetOutputPrecision(quad_float_significant_digits); // significant decimal digits.
	cout << (PrecisionOK() ? "Precision OK\n" : "Precision not OK!\n");
	cout.precision(quad_float_significant_digits);

	quad_float l =  to_quad_float("3.1415926535897932384626433832794319232571146478579031130162172065489745165223212097771465778350830078125");
	quad_float m = to_quad_float("3.14159265358979323846264338327950288419716940075302929584103285579371202800448997465293046115320802958337");
	quad_float h =  to_quad_float("3.141592653589793238462643383279530530870267274333579579086877554827683667326709837652742862701416015625");
	
	cout << "quad_float using 105 significand bits" << endl;
	cout << "l " << l << endl;
	outAsHex(l.lo);
	outAsHex(l.hi);
	cout << endl;

	cout << "m " << m << endl;
	outAsHex(m.lo);
	outAsHex(m.hi);
	cout << endl;

	cout << "h " << h  << endl;
	outAsHex(h.lo);
	outAsHex(h.hi);
	cout << endl;
	check(l, m, h);

	l  = to_quad_float("3.14159265358979323846264338327948122706369096109574134605154738068832909192451552371494472026824951171875");
	m = to_quad_float("3.141592653589793238462643383279502884197169400753029295841032855793712028004489974652930461153208029583374");
	h  = to_quad_float("3.141592653589793238462643383279530530870267274333579579086877554827683667326709837652742862701416015625");

	cout << "quad_float using 106 significand bits" << endl; // uses two double each with 53 significand bits. 
	cout << "l " << l  << endl;
	outAsHex(l.lo);
	outAsHex(l.hi);
	cout << endl;

	cout << "m " << m  << endl;
	outAsHex(m.lo);
	outAsHex(m.hi);
	cout << endl;

	cout << "h " << h  << endl;
	outAsHex(h.lo);
	outAsHex(h.hi);
	cout << endl;
	check(l, m, h); // This warns that a tighter interval is possible (+1 and -1 ulp).

	l = to_quad_float("3.14159265358979323846264338327948122706369096109574134605154738068832909192451552371494472026824951171875");
	m = to_quad_float("3.141592653589793238462643383279502884197169400753029295841032855793712028004489974652930461153208029583374");
	h = to_quad_float("3.141592653589793238462643383279505878966979117714660462569212467758006379625612680683843791484832763671875");

	cout << "quad_float using 107 significand bits" << endl;
	cout << "l " << l  << endl;
	outAsHex(l.lo);
	outAsHex(l.hi);
	cout << endl;

	cout << "m " << m  << endl;
	outAsHex(m.lo);
	outAsHex(m.hi);
	cout << endl;

	cout << "h " << h << endl;
	outAsHex(h.lo);
	outAsHex(h.hi);
	cout << endl;

	check(l, m, h);  // This gives the tightest interval and middle == upper limits.

	/*


Math constants intervals test_quad_float.cpp Thu Oct 10 17:48:26 2002
NTL version 5.2 , Compiled with MSVC++ version 1300
quad_float_significant_digits 33

Precision OK

quad_float using 105 significand bits
l 3.14159265358979323846264338327943 1.2246467991473525e-016 3.1415926535897931
1.2246467991473525e-016 == 0x3ca1a62633145c04
3.1415926535897931 == 0x400921fb54442d18

m 3.14159265358979323846264338327951 1.2246467991473532e-016 3.1415926535897931
1.2246467991473532e-016 == 0x3ca1a62633145c07
3.1415926535897931 == 0x400921fb54442d18

h 3.14159265358979323846264338327953 1.2246467991473535e-016 3.1415926535897931
1.2246467991473535e-016 == 0x3ca1a62633145c08
3.1415926535897931 == 0x400921fb54442d18

WARNING : middle is neither lower nor upper limit!
WARNING : more precise interval possible!
quad_float using 106 significand bits
l 3.14159265358979323846264338327948 1.224646799147353e-016 3.1415926535897931
1.224646799147353e-016 == 0x3ca1a62633145c06
3.1415926535897931 == 0x400921fb54442d18

m 3.14159265358979323846264338327951 1.2246467991473532e-016 3.1415926535897931
1.2246467991473532e-016 == 0x3ca1a62633145c07
3.1415926535897931 == 0x400921fb54442d18

h 3.14159265358979323846264338327953 1.2246467991473535e-016 3.1415926535897931
1.2246467991473535e-016 == 0x3ca1a62633145c08
3.1415926535897931 == 0x400921fb54442d18

WARNING : middle is neither lower nor upper limit!
WARNING : more precise interval possible!

quad_float using 107 significand bits
l 3.14159265358979323846264338327948 1.224646799147353e-016 3.1415926535897931
1.224646799147353e-016 == 0x3ca1a62633145c06
3.1415926535897931     == 0x400921fb54442d18

m 3.14159265358979323846264338327951 1.2246467991473532e-016 3.1415926535897931
1.2246467991473532e-016 == 0x3ca1a62633145c07
3.1415926535897931      == 0x400921fb54442d18

h 3.14159265358979323846264338327951 1.2246467991473532e-016 3.1415926535897931
1.2246467991473532e-016 == 0x3ca1a62633145c07
3.1415926535897931      == 0x400921fb54442d18

middle is upper limit.


Press any key to continue
*/



} // int main()

void check(quad_float l,quad_float m, quad_float h)
{
	// Check that 'middle' quad_float value is either upper or lower interval, or both. 
	bool is_lower = static_cast<bool>(l == m);
	bool is_upper = bool(h == m);
	// 'performance' warning C4800 here.

	if (is_lower && is_upper)
	{ // Both.
		cout << "lower, middle & upper are same." << endl;
	}
	else
	{ // Different, but expect upper or lower to be same as middle.
		if (is_lower)
		{
			cout << "middle is lower limit." << endl;
		}
		if (is_upper)
		{
			cout << "middle is upper limit." << endl;
		}
		if (!(is_lower) && !(is_upper))
		{ // Neither!
			std::cerr << "WARNING : middle is neither lower nor upper limit!" << std::endl;
			if (m > h)
			{
				std::cerr << "WARNING : middle > upper limit!" << std::endl;
			}
			if (m < l)
			{
				std::cerr << "WARNING : middle < lower limit!" << std::endl;
			}
		}
		quad_float lp = l + h; // lower + upper
		quad_float two = to_quad_float(2.);
		if ((lp < two * h) && (lp > two * l))
		{
			std::cerr << "WARNING : more precise interval possible!" << std::endl;
		}
	}
} // Check



void outAsHex(float d)
{
	fhex fd = {d};  // Initialise float fd.d = 0.0;
	char fill = cout.fill('0'); // save
	int fmtflags = cout.flags();
	cout << dec << fd.f << " == 0x" << hex << fd.l << endl;
	cout.flags(fmtflags); // Restore.
}  // displayAsHex

void outAsHex(double d)
{
	dhex dd = {d};  // Initialise double dd.d = 0.0;
	// Assume Intel 8087 FP - not sure this is right?
	// P J Plaguer p 67.
	char fill = cout.fill('0'); // save
	int fmtflags = cout.flags();
	cout << dec << dd.d << " == 0x" << hex << right
		<< setw(4) << dd.usa[3] // SCCC CCCC CCCC FFFF  sign & exponent.
		<< setw(4) << dd.usa[2] // CCCC
		<< setw(4) << dd.usa[1] // CCCC
		<< setw(4) << dd.usa[0] // FFFF
		<< endl;
		cout.flags(fmtflags); // Restore 
		cout.fill(fill);

}  // displayAsHex


/*

*/