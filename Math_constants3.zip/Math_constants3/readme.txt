Math_constants3\readme.txt

This 3rd try at math constants provides the following files:

New documentation provided as html zipped as math_constants_docs_3.html
in a folder html docs zipped.  This is in fairly standard Boost format.
(Prepared using MS Frontpage, hopefully now free of troubles
caused by MS Word's funny ideas about html - it not please tell me!)


    FileName	                  Description

headers containing constants

  define_constants.h	          C Macro constants
  undefine_constants.h	        file with C macro #undefs

  float_constants.hpp	          C++ const float constants
  constants.hpp	                C++ const double constants
  long_constants.hpp	          C++ const long double constants
  function_constants.hpp        C++ constant class function template version.

Some collected values for checking

  HartConstants1.TXT	          textbook constants
  HartConstants2.TXT	          More obscure textbook constants.
  knuth Constants.h	            constants from Knuth

  Math_constants*.htm	          NEW documentation - read this 2nd!

Various test programs, within a sub-directory with MCVS 7 vcproj files.

  testDefineConstants.cpp   	  simple test of define_constants.hpp file.
  testDoubleConstants.cpp	      simple test of double using constants.hpp file...
  testFloatConstants.cpp	      simple test of float constants using float_constants.hpp
  testLongDoubleConstants.cpp	  simple test of long double constants using long_double_constants.hpp.
  Pi.cpp                        simple test of Kenniston's function constants.
  testFunctionConstants.cpp   	fuller demo of Kenniston's function constants.

Interval constants

	test_pi_interval							simple example shows interval contained pi
	template_interval_constants   further examples of interval pi
	test_quad_float               Demo of a UDT interval of pi.
	test_sparec_intervals	        Confirmation of the 128 bit long double interval of pi.

info about hardware dependent ideas (not used)

  Itanium FPregister.rtf	      Intel info about Itanium FP register
  X86ControlWord.cpp	          example of fiddling with X86 control word (not used)
  builtin_constants.cpp       	example of using X86 coprocessor builtin values,
  builtin_constants.h	          but which are not used - see FAQ.

  math_constants_3.zip	        zip of all these files.

  Paul Bristow  Dec 2002
