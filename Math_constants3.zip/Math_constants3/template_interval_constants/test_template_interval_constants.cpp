// test_interval_constants.cpp

// Demo of using interval constants.

// (C) Copyright Paul A Bristow, hetp Chromatography, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <iostream>
#include <iomanip>

#include "template_interval_constants.hpp" // for smallest interval containing pi.

using std::cout;
using std::endl;

int main()
{
	cout << "Test " << __FILE__ << ' ' << __TIMESTAMP__ << endl;

	// Ensure all significant decimal digits are output.
	// significant decimal digits are calculated from the
	// number of significand (mantissa) binary digits,
	// given by  std::numeric_limits<floating_point_type>::digits, typically 24, 53, 60, or 113,
	// provided it is specialized for the floating_point_type.
	// NB Significant difference between significanT and significanD!
	int float_significand_digits =  std::numeric_limits<float>::digits; // 24 bits.
	int float_significant_digits =  2 + std::numeric_limits<float>::digits * 30101/100000;
	int double_significand_digits =  std::numeric_limits<double>::digits; // 53 bits.
	int double_significant_digits =  2 + std::numeric_limits<double>::digits * 30101/100000; // 53 bits for MSVC.
	int long_double_significand_digits = std::numeric_limits<long double>::digits; // also 53 for MSVC,
	// but 64 for gcc long double, 128 for Sparc and VMS H ...
	int long_double_significant_digits = std::numeric_limits<long double>::digits * 30101/100000; 
	// would be same as double on MSVC, so don't always use this.
	// 64 for Extended-double precision X86 80 bit (double only 53).

	// Example of float.
	cout << "\nstd::numeric_limits<float>::digits = " << float_significand_digits  << endl;
	cout << "float significant digits = " << float_significant_digits  << endl;
	cout.precision(float_significant_digits);
	cout << "pi<float>::lower()   "   << pi<float>::lower() << endl;	
	cout << "pi<float>::nearest() " << pi<float>::nearest() << endl;
	cout << "pi<float>::upper()   "   << pi<float>::upper() << endl;
	check_interval_values(pi<float>::lower(), pi<float>::nearest(), pi<float>::upper() );

	// Example of double.
	cout << "std::numeric_limits<double>::digits = " << double_significand_digits  << endl;
	cout << "\ndouble significant digits = " << double_significant_digits  << endl;
	cout.precision(double_significant_digits);
	cout << "pi<double>::lower()   "   << pi<double>::lower() << endl;	
	cout << "pi<double>::nearest() " << pi<double>::nearest() << endl;
	cout << "pi<double>::upper()   "   << pi<double>::upper() << endl;

	// Using the builtin long double precision.
	cout << "std::numeric_limits<long double>::digits = " << long_double_significand_digits  << endl;
	cout << "\nlong double significant digits = " << long_double_significant_digits  << endl;
	cout.precision(long_double_significant_digits);
	cout << "pi<long double>::lower()   "   << pi<long double>::lower() << endl;	
	cout << "pi<long double>::nearest() " << pi<long double>::nearest() << endl;
	cout << "pi<long double>::upper()   "   << pi<long double>::upper() << endl;

	// Picking a different specialization for X86 double extended precision.
	long_double_significand_digits = 64; // Extended double precision X86 80 bit (double only 53).
	cout << "\nX86 extended long double std::numeric_limits<long double>::digits = " << long_double_significand_digits  << endl;
	long_double_significant_digits =  2 + long_double_significand_digits * 30101/100000;
	cout << "X86 extended long double significant digits = " << long_double_significant_digits  << endl;
	cout.precision(long_double_significant_digits); // Only effective if really uses 80-bit FP!
	cout << "pi<long double>::lower()   "   << pi<long double, 64>::lower() << endl;	
	cout << "pi<long double>::nearest() " << pi<long double, 64>::nearest() << endl;
	cout << "pi<long double>::upper()   "   << pi<long double, 64>::upper() << endl;

	// Example of a user-defined floating-point type.
	int quad_float_significand_digits = 106; // 53 + 53
	// numeric_limits is NOT specialized for quad_float, so can't use
	// int quad_float_significand_digits = std::numeric_limits<quad_float>::digits;
	int quad_float_significant_digits = 2 + quad_float_significand_digits * 30101/100000; // 33
	cout << "\nquad_float significand digits = " << quad_float_significand_digits  << endl;
	cout << "quad_float significant digits = " << quad_float_significant_digits  << endl;
	quad_float::SetOutputPrecision(quad_float_significant_digits); // significant decimal digits.
	cout << (NTL::PrecisionOK() ? "quad_float::SetOutputPrecision OK\n" : "quad_float::SetOutputPrecision not OK!\n");
	// cout.precision(quad_float_significant_digits);
	// is ineffective for quad_float - MUST use quad_float::SetOutputPrecision() instead.

	cout << "pi<quad_float>::lower()   "   << pi<quad_float>::lower() << endl;	
	cout << "pi<quad_float>::nearest()   "   << pi<quad_float>::nearest() << endl;	
	cout << "pi<quad_float>::upper()   "   << pi<quad_float>::upper() << endl;

	// Example of a unsuitable type for pi - byte!
	// cout << "pi<byte>::lower()   "   << pi<byte>::lower() << endl;	
	// Fails to compile because no specialisation of pi for type byte,
	// which may catch some mistake?

	// Example of a non-floating-point type - not very practical approx to pi!
	cout << "\npi<int>::lower()   "   << pi<int>::lower() << endl;	
	cout << "pi<int>::nearest()   "   << pi<int>::nearest() << endl;	
	cout << "pi<int>::upper()   "   << pi<int>::upper() << endl;	
	// But this could be useful for other constants which really are integral?

	return 0;
}  // int main()

/*

Test test_template_interval_constants.cpp Wed Dec 11 19:25:29 2002

std::numeric_limits<float>::digits = 24
float significant digits = 9
pi<float>::lower()   3.1415925
pi<float>::nearest() 3.14159274
pi<float>::upper()   3.14159274
nearest is upper limit.
std::numeric_limits<double>::digits = 53

double significant digits = 17
pi<double>::lower()   3.1415926535897931
pi<double>::nearest() 3.1415926535897931
pi<double>::upper()   3.1415926535897936
std::numeric_limits<long double>::digits = 53

long double significant digits = 15
pi<long double>::lower()   3.14159265358979
pi<long double>::nearest() 3.14159265358979
pi<long double>::upper()   3.14159265358979

X86 extended long double std::numeric_limits<long double>::digits = 64
X86 extended long double significant digits = 21
pi<long double>::lower()   3.1415926535897931
pi<long double>::nearest() 3.1415926535897931
pi<long double>::upper()   3.1415926535897931

quad_float significand digits = 106
quad_float significant digits = 33
quad_float::SetOutputPrecision OK
pi<quad_float>::lower()   3.14159265358979323846264338327948
pi<quad_float>::nearest()   3.14159265358979323846264338327951
pi<quad_float>::upper()   3.14159265358979323846264338327951

pi<int>::lower()   3
pi<int>::nearest()   3
pi<int>::upper()   4
Press any key to continue
*/