// template_intervals_constants.hpp

// Sample of smallest interval constant for pi
// (and lots of attempts, diueas and discussions as comments).

// (C) Copyright Paul A Bristow, hetp Chromatography, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <limits> // for numeric_limits digits and radix
#include <NTL/quad_float.h> // for quad_float, a user defined floating point type.

using NTL::quad_float;
using NTL::to_quad_float;

namespace
{ // Anonymous.
	// Pi Exactly C++ representable values, calculated using 300 bit NTL,
	// for various common radix.

	// IEEE float, radix 2, 24 significand digits.
	static const float pi_f_lower = 3.141592502593994140625F;
	static const float pi_f_upper = 3.1415927410125732421875F;
	static const float pi_f_nearest = 3.14159265358979323846264338327950288419716939937510F;

	// IEEE double, radix 2, 53 significand digits.
	static const double pi_d_lower = 3.141592653589793115997963468544185161590576171875;
	static const double pi_d_upper = 3.141592653589793560087173318606801331043243408203125;
	static const double pi_d_nearest = 3.14159265358979323846264338327950288419716939937510;

	// IEEE long double, radix 2, 64 significand digits.
	static const long double pi_l_nearest = 3.141592653589793238462643383279502884197169400753029295841032855793712028004489974652930461153208029583374L;
	static const long double pi_l_lower = 3.14159265358979323846264338327948122706369096109574134605154738068832909192451552371494472026824951171875L;
	static const long double pi_l_upper = 3.141592653589793238462643383279530530870267274333579579086877554827683667326709837652742862701416015625L;

  // Exactly representable in 128 bit SPARC & VAX H double extended format smallest interval values of pi.
	static const long double pi_ll_lower = 3.141592653589793238462643383279502797479068098137295573004504331874296718662975536062731407582759857177734375L;
	static const long double pi_ll_nearest   = 3.1415926535897932384626433832795028841971694007530292958410328557937120280044899746529304611532080295833741639955L;
	static const long double pi_ll_upper = 3.141592653589793238462643383279503182665056975584466184200092848859760426283305179140370455570518970489501953125L;

	// Examples of values for integer, used to show a user specialization.
	// Only useful for US state of Indiana with math-challenged legislators?
	// See www.urbanlegends.com
	static const int pi_i_lower = 3;
	static const int pi_i_nearest = 3;
	static const int pi_i_upper = 4;
} // Anonymous namespace

template <class FPtype, int digits = std::numeric_limits<FPtype>::digits, int radix  = std::numeric_limits<FPtype>::radix >
class pi;
// Default digits and radix are from std::numeric_limits,
// but could be made different for special floating point types
// that don't provide numeric_limits.

// Specializations for builtin floating point types.
// TODO use macro?
template <>
class pi<float>
{
public:
	static const float lower()
	{
		return pi_f_lower;
	}
	static const float upper()
	{
		return pi_f_upper;
	}
	static const float nearest()
	{ // nearest should == either lower or upper.
		return pi_f_nearest;
	}
}; // template <> class pi<float>

template <>
class pi<double>
{ // Specialization for double.
public:
	static const double lower()
	{
		return pi_d_lower;
	}
	static const double upper()
	{
		return pi_d_upper;
	}
	static const double nearest()
	{
		return pi_d_nearest;
	}
}; // template <> class pi<double>

template <>
class pi<long double>
{ // Specialization for long double, X86 double precision,
	// used by MSVC which is 53, same as double,
public:
	static const long double lower()
	{
		return pi_d_lower;
	}
	static const long double upper()
	{
		return pi_d_upper;
	}
	static const long double nearest()
	{
		return pi_d_nearest;
	}
}; // template <> class pi<long double>

// Other example specializations.

// Note that specializing 
// template <> class pi<long double, 53> means
// must specify pi<long double, 53, 2>::upper()
// and NOT specialize template <> class pi<long double>

template <>
class pi<long double, 64>
{ // Specialization for long double, X86 extended double precision.
	// used by GCC, but NOT by MSVC which is 53, same as double,
	// so would be wrong on MSVC.
public:
	static const long double lower()
	{
		return pi_l_lower;
	}
	static const long double upper()
	{
		return pi_l_upper;
	}
	static const long double nearest()
	{
		return pi_l_nearest;
	}
}; // template <> class pi<long double, 64>

template <>
class pi<int>
{ // Specialization for integer - NOT very practical!!!!
	// but shows difference between unsigned int which deliberately is NOT specialized,
	// and fails helpfully as expected at compile time.
public:
	static const int lower()
	{
		return pi_i_lower;
	}
	static const int upper()
	{
		return pi_i_upper;
	}
	static const int nearest()
	{
		return pi_i_nearest;
	}
}; // template <> class pi<int>


template <>
class pi<quad_float>
{ // Specialization for NTL quad_float (aka doubledouble), uses two doubles for 106 significand bits.
	// An example of a special user type, which could be specialized by the user,
	// probably in a separate header file, for example myfloat.hpp
public:
	static const quad_float lower()
	{ // to_quad_float converts from C string to quad_float - 
		return to_quad_float("3.14159265358979323846264338327948122706369096109574134605154738068832909192451552371494472026824951171875");
	}
	static const quad_float upper()
	{
		return to_quad_float("3.141592653589793238462643383279502884197169400753029295841032855793712028004489974652930461153208029583374");
	}
	static const quad_float nearest()
	{
		return to_quad_float("3.141592653589793238462643383279505878966979117714660462569212467758006379625612680683843791484832763671875");
	}
}; // template <> class pi<quad_float>

// template <> class pi<quad_float, 106, 2> would mean need to

// Alternative switch scheme.
/*

Conclude that this switch scheme doesn't really work well, if at all,
because

1  radix and digits must be from numeric_limits

2  Need to check Floating point type to suffix correctly, F, nothing, or L.

3  Hinders/prevents extension to other floating point types (see quad_float example above).


template<typename FPtype>
const FPtype pi_lower()
{
	int digits = std::numeric_limits<FPtype>::digits; // significand binary digits.
	int radix = std::numeric_limits<FPtype>::radix; // only defined for radix 2, so far.

	FPtype lower =
		(radix == 2) ?
		( // Expected radix.
		(digits == 113) ? 3.141592653589793238462643383279502797479068098137295573004504331874296718662975536062731407582759857177734375L
		// value for 113 bits.
		: (digits == 64) ?  3.14159265358979323829596852490908531763125210004425048828125L // value for significand 64 bits.
		:	(digits == 53) ?  3.141592653589793115997963468544185161590576171875 // value for significand 53 bits.
		:	(digits == 24) ?  
		// Must test FPtype to find if value is a float, double or long double and suffix is F, nothing or L.
		// Because value must be exactly representable, we MUST avoid conversion.
		(typeof(FPtype == float) ? 3.141592502593994140625F // value for float significand 24 bits.
			: typeof(FPtype == double) ? 3.141592502593994140625 // value for double significand 24 bits.
			: typeof(FPtype == double) ? 3.141592502593994140625L // value for long double significand 24 bits.
			: std::numeric_limits<FPtype>::quiet_NaN() // value for any other significand 24 bits.
			// How to deal with other FP types?
		)
		: 3 // Unknown and/or unimplemented floating point significand 
		)
		: std::numeric_limits<FPtype>::quiet_NaN(); // unknown and/or unimplemented floating point radix!
	// BUT disadvantage is that it only shows at run-time, not compile time.
	return lower;

	// Is there a problem here with the type letter?

	Need typeof()
	// Should have a F only for FPtype == float,
	// and L only for FPtype == long double.
} // template<type FPtype> const FPtype lower()
*/

template <typename FPtype>
bool check_interval_values(FPtype l, FPtype n, FPtype u)
{ // Check that 'nearest' FPtype value is either upper or lower interval, or both,
	// and interval is as small as possible.
	bool is_OK = true; // == No warnings.
	bool is_lower = static_cast<bool>(l == n);
	bool is_upper = static_cast<bool>(u == n);
	if (is_lower && is_upper)
	{ // Both.
		cout << "lower, nearest & upper are same." << endl;
	}
	else
	{ // Different, but expect upper or lower to be same as nearest.
		if (is_lower)
		{
			cout << "nearest is lower limit." << endl;
		}
		if (is_upper)
		{
			cout << "nearest is upper limit." << endl;
		}
		if (!(is_lower) && !(is_upper))
		{ // Neither!
			std::cerr << "WARNING : nearest is neither lower nor upper limit!" << std::endl;
			is_OK = false;
			if (n > u)
			{
				std::cerr << "WARNING : nearest > upper limit!" << std::endl;
				is_OK = false;
			}
			if (n < l)
			{
				std::cerr << "WARNING : nearest < lower limit!" << std::endl;
				is_OK = false;

			}
		}
		FPtype lp = l + u; // lower + upper
		FPtype two = FPtype(2.L);
		if ((lp < two * u) && (lp > two * l))
		{
			std::cerr << "WARNING : more precise interval possible!" << std::endl;
			is_OK = false;
		}
	}
	return is_OK;
} // Check



/* 
// Suggested by Herve Bronnimann [hbr@poly.edu]
// If you want to take advantage of compile-time,
// template arguments of the form <unsigned int> would work, and
// specializations for various ints would give you the desired rounding.

Doesn't work directly as suggested by Sylvian Pion

C2864 only const static integral data members can be initialized
INSIDE a class or struct
	static const int lower = 3; // allowed but not double like:
	static const double lower = 3.141592653589793115997963468544185161590576171875;
	

template <unsigned int decimal_precision>
struct interval_pi
{ // integer version to be used as default.
	static const double lower = 3.; // integer default version. C2864
	static const double upper = 4.; // 3 < pi < 4
};

but this compiles OK.

template <unsigned int decimal_precision>
struct interval_pi
{ // integer version to be used as default.
	static const int lower = 3.; // integer default version. 
	static const int upper = 4.; // 3 < pi < 4
};

// n decimal digits, l lower interval constant in decimal, u upper constant in decimal
#define BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(n, l, u) \
	template <> struct interval_pi<n>\
{ \
	static const double lower = l;  \
	static const double upper = u;  \
}

BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(1,  3.1          , 3.2          );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(2,  3.14         , 3.15         );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(3,  3.141        , 3.142        );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(4,  3.1415       , 3.1416       );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(5,  3.14159      , 3.14160      );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(6,  3.1415926    , 3.1415927    );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(7,  3.14159265   , 3.14159266   );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(8,  3.141592653  , 3.141592654  );
BOOST_INTERVAL_SPECIALIZE_PI_CONSTANT(9,  3.1415926535 , 3.1415926536 );

std::cout << interval_pi<7>::lower << std::endl;

static const float pi_f_l = 3.141592502593994140625F;
static const float pi_f_u = 3.1415927410125732421875F;

Guillaume Melquiond [gmelquio@ens-lyon.fr]

I'm surprised it worked with gcc 2.95 and 3.2 since I did try such a
solution and it didn't work. I needed to put them out of the classes and
to use functions inside the class to return the global constants. It was
ugly but sufficient.

I seem to remember that it isn't allowed by the Standard to define
floating-point constants inside a class.  This was also said to be true.
SO MSCV is correct in forbidding it.


This below doesn't work  C2864 MSVC 7.0
Posted request for help 16 Oct 2002 - confirmed this is correct.

template <>
class pi<float, 2, 24>
{
	static const float lower =   3.1415925025939941406250F;
	static const float upper =   3.1415927410125732421875F;
	static const float nearest = 3.14159265358979323846264338327950288419716939937510F;
};

template <class T, int radix, int digits>
class pi
{ // falling back on a lower precision available
	static const T upper = pi<T, radix, digits-1>::upper;
	static const T lower = pi<T, radix, digits-1>::upper;
	static const T nerest = pi<T, radix, digits-1>::upper;
};


Original code - assumes radix = 2 and digits = 24 & 53

static const float pi_f_l = 13176794.0f/(1<<22);
static const float pi_f_u = 13176795.0f/(1<<22);
static const double pi_d_l = (3373259426.0 + 273688.0 / (1<<21)) / (1<<30);
static const double pi_d_u = (3373259426.0 + 273689.0 / (1<<21)) / (1<<30);

Sylvain Pion [pion@cs.nyu.edu]

The template solution has advantages : it can simply refuse to compile if you
try to ask a digits/radix pair of values which you have not planned.
With the initial switch I proposed, you can only get a run-time error.

The template solution is also more easily extensible as Herve said :
you don't need to have only one big statement in only one file,
you can spread the various versions over several files.

So I guess you could write your constants like :

template <class T, int radix  = std::numeric_limits<T>::radix,
int digits = std::numeric_limits<T>::digits>
class pi;

template <>
class pi<float, 2, 24>
{
static const float upper   = ...;
static const float lower   = ...;
static const float nearest = ...;
};


Either you refuse to compile if the value is not planned,
or you can have the
template falling back on a lower precision available :

template <class T, int radix, int digits>
class pi {
static const T upper = pi<T, radix, digits-1>::upper;
...
};

gmelquio@ens-lyon.fr
It is stated in the documentation on the base type
requirements: "If these values are not provided by the user, the default
values will be used: they are integer values (so pi is bounded by 3 and
4)." The user has to provide its own constants if it doesn't use an
interval based on 'float' or 'double'.

See html documentation for a properly laid out table!
Decimal digits that are required for accurate input,
the lower value is the number guaranteed correct on output.
Floating point Type(common C++ type)	Commonly used for C/C++ type	Totalbits	Significandbits	guaranteed digits10decimaldigits	significant decimaldigits
IEEE single	float	32	23 + 1 = 24	6	9
VAX F 	float	32	23 + 1 = 24	6	9
IBM G/390 short	float	32	24	6	9
IEEE single extended 	?	>=43	>=32	7	11
IEEE double	double	64	52 + 1 = 53	15	17
VAX G 	double	64	52 + 1 = 53	15	17
IBM G/390 long	double	64	56	15	17
VAX D	long double	64	56	15	17
IEEE double extended	long double	80	>=64	19	21
NTL quad	�quad�	128	106	31	33
IBM G/390 extended	long double	128	112	33	35
VAX H	long double	128	112 + 1 = 113	34	36
IEEE quadruple	long double	128	112 + 1 = 113	34	36
signed fractional	?	127	128	38	40
unsigned fractional	?	128	128	38	40

*/
