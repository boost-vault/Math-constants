// testDoubleConstants.cpp

// (C) Copyright Paul A Bristow, hetp Chromatography, 2001, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <iostream>
#include <limits> // for digits10

#include "\Cpp\WinNTL-5_0c\NTL5\makeConstants\constants.hpp"

using std::cout;
using std::endl;

int main()
{
	cout << "Test " << __FILE__ << ' ' << __TIMESTAMP__ << endl;

	cout.precision(std::numeric_limits<double>::digits10 +2);
	// Ensure all significant decimal digits are shown.
	cout << "double pi = " << pi << endl;
	cout << "double e = " << e << endl;
	cout << "double sqrt2 = " << sqrt2 << endl;

	return 0;
}  // int main()


/*

	Output:

Test j:\cpp\winntl-5_0c\ntl5\testdoubleconstants\testdoubleconstants.cpp Tue Oct
16 15:33:16 2001
double pi = 3.1415926535897931
double e = 0.57721566490153287
double sqrt2 = 1.4142135623730951
Press any key to continue

	*/