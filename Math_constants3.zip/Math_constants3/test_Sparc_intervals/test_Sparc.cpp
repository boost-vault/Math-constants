// Test SPARC 128 bit double extended (quad) format
// long double smallest intervals of math constant pi
// Confirms these values are correct - see below.

// Paul A Bristow, Oct 2002

#include <iostream>
#include <limits> // for numeric limits.

using std::cout;
using std::endl;

// Exactly representable in 128 bit SPARC & VAX H double extended format smallest interval values of pi.

static const long double pi_l = 3.141592653589793238462643383279502797479068098137295573004504331874296718662975536062731407582759857177734375L;
static const long double pi   = 3.1415926535897932384626433832795028841971694007530292958410328557937120280044899746529304611532080295833741639955L;
static const long double pi_u = 3.141592653589793238462643383279503182665056975584466184200092848859760426283305179140370455570518970489501953125L;

void check(long double l,long double m, long double h);

int main()
{
	int long_double_significant_digits =  2 + 113 * 30101/100000; // 36
	cout << "long double_significant_digits " << long_double_significant_digits << endl;
	cout.precision(long_double_significant_digits);  // Show all possibly significant.

	cout << "std::numeric_limits<long double>::digits = " << std::numeric_limits<long double>::digits << endl;
	// Expect 112 + 1 implicit = 113 significand or mantissa bits.

	cout << "pi_l = " << pi_l << endl;
	cout << "pi = " << pi << endl;
	cout << "pi_u = " << pi_u << endl;

	check(pi_l, pi, pi_u); // Expect middle is either upper or lower limit, but not both.
	// and no warnings!

	return 0;
} // int main()

void check(long double l,long double m, long double h)
{
	// Check that 'middle' long double value is either upper or lower interval, or both. 
	bool is_lower = static_cast<bool>(l == m);
	bool is_upper = static_cast<bool>(h == m);
	if (is_lower && is_upper)
	{ // Both.
		cout << "lower, middle & upper are same." << endl;
	}
	else
	{ // Different, but expect upper or lower to be same as middle.
		if (is_lower)
		{
			cout << "middle is lower limit." << endl;
		}
		if (is_upper)
		{
			cout << "middle is upper limit." << endl;
		}
		if (!(is_lower) && !(is_upper))
		{ // Neither!
			std::cerr << "WARNING : middle is neither lower nor upper limit!" << std::endl;
			if (m > h)
			{
				std::cerr << "WARNING : middle > upper limit!" << std::endl;
			}
			if (m < l)
			{
				std::cerr << "WARNING : middle < lower limit!" << std::endl;
			}
		}
		long double lp = l + h; // lower + upper
		long double two = long double(2.L);
		if ((lp < two * h) && (lp > two * l))
		{
			std::cerr << "WARNING : more precise interval possible!" << std::endl;
		}
	}
} // Check

/*

MSVC 7.0


long double_significant_digits 36
std::numeric_limits<long double>::digits = 53 <<<<< SPARC should be 113
pi_l = 3.1415926535897931
pi = 3.1415926535897931
pi_u = 3.1415926535897931
lower, middle & upper are same.<<<<< SPARC should be different.
Press any key to continue



On 10/10/2002, at 4:04 PM Paul A. Bristow wrote:

> I would be most grateful for anyone with a SPARC system and/or a VAX with H
> format)
> to test the calculation of constants (in this case pi) intervals.

Paul,

The system I use is the following:

SunOS gradlab.ucsd.edu 5.8 Generic_108528-14 sun4u sparc SUNW,Ultra-60

The compiler is CC:

CC: Sun WorkShop 6 update 1 C++ 5.2 2000/09/11

It  barked  about a badly formed expression on line 71. I have changed
it:

From:
        long double two = long double(2.L);
To:
        long double two = (long double)(2.L);

This compiled and produced the following output:

--------------------------------------------------
long double_significant_digits 36
std::numeric_limits<long double>::digits = 113
pi_l = 3.1415926535897932384626433832795028
pi   = 3.1415926535897932384626433832795028
pi_u = 3.14159265358979323846264338327950318
middle is lower limit.
--------------------------------------------------

If  you want to have some additional tests compiled and run, send your
sources to me.

Leo.


Leo Landa [leo@leolan.com]
_______________________________________________
Unsubscribe & other changes: http://lists.boost.org/mailman/listinfo.cgi/boost



*/
