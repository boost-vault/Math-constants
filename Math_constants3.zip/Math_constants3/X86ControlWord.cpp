// X86ControlWord.cpp

// Example of X86 Floating_point control word manipulation
// Compiled with MSVC6 SP5.

 // (C) Copyright Paul A Bristow, hetp Chromatography, 2001, 2002
 // Permission to copy, use, modify, sell and distribute this software
 // is granted provided this copyright notice appears in all copies.
 // This software is provided "as is" with express or implied warranty,
 // and with no claim as to its suitability for any purpose.*/

#include <iostream>
#include <iomanip> // for setprecision
#include <limits> // for numeric_limits
#include <cfloat>  // for _control87

//#include "math_constants.h"

using std::cout;
using std::endl;
using std::setprecision;
using std::hex;
using std::dec;

unsigned int _controlfp(unsigned int newControl, unsigned int mask); // Get/set control word
// _controlfp is portable between X86, MIPS and Alpha using mask values provided by Microsoft.
unsigned int _control87(unsigned int newControl, unsigned int mask); // Get/set control word
// _control87 is only for Intel.
unsigned int _statusfp(void); // get Floating point status word.
unsigned int _clear87(void); // Clear floating point status word.

// Floating point control & status values from float.h
#ifndef _MAC
#define _MCW_EM         0x0008001f   /* interrupt Exception Masks */
#else
#define _MCW_EM         0x0000001f   /* interrupt Exception Masks */
#endif
#define _EM_INEXACT     0x00000001              /*   inexact (precision) */
#define _EM_UNDERFLOW   0x00000002              /*   underflow */
#define _EM_OVERFLOW    0x00000004              /*   overflow */
#define _EM_ZERODIVIDE  0x00000008              /*   zero divide */
#define _EM_INVALID     0x00000010              /*   invalid */

#define _MCW_RC         0x00000300  /* Rounding Control */
#define _RC_NEAR        0x00000000              /*   near */
#define _RC_DOWN        0x00000100              /*   down */
#define _RC_UP          0x00000200              /*   up */
#define _RC_CHOP        0x00000300              /*   chop */

/*
 * Abstract User Status Word bit definitions (not X87 control word bits!)
 */

#define _SW_INEXACT     0x00000001              /* inexact (precision) */
#define _SW_UNDERFLOW   0x00000002              /* underflow */
#define _SW_OVERFLOW    0x00000004              /* overflow */
#define _SW_ZERODIVIDE  0x00000008              /* zero divide */
#define _SW_INVALID     0x00000010              /* invalid */

/*
 * i386 specific definitions
 */
#define _MCW_PC         0x00030000              /* Precision Control */
#ifdef  _M_MPPC
/*
 * PowerMac specific definitions(no precision control)
 */
#define _PC_64          0x00000000              /*    64 bits */
#define _PC_53          0x00000000              /*    53 bits */
#define _PC_24          0x00000000              /*    24 bits */
#else
#define _PC_64          0x00000000              /*    64 bits */
#define _PC_53          0x00010000              /*    53 bits */
#define _PC_24          0x00020000              /*    24 bits */
#endif

#define _MCW_IC         0x00040000              /* Infinity Control */
#define _IC_AFFINE      0x00040000              /*   affine */
#define _IC_PROJECTIVE  0x00000000              /*   projective */

#define _EM_DENORMAL    0x00080000              /* denormal exception mask (_control87 only) */

#define _SW_DENORMAL    0x00080000              /* denormal status bit */

void showStatus()
{ // Read, show and clear floating point status word.
	unsigned int statusfp = _statusfp();
	cout << "87 FP status word register  " << hex << statusfp << ' ';
	if (statusfp & 0)
		cout << " OK";
	if (statusfp & _SW_INEXACT)
		cout << " inexact";
	if (statusfp & _SW_UNDERFLOW)
		cout << " underflow";
	if (statusfp & _SW_OVERFLOW)
		cout << " overflow";
	if (statusfp & _SW_ZERODIVIDE)
		cout << " zerodivide";
	if (statusfp & _SW_INVALID)
		cout << " invalid";
	if (statusfp & _SW_DENORMAL)
		cout << " denormal";

	cout << endl;
	_clearfp(); // Otherwise bits set so far are remembered.
	// Clearing bits might not be most useful!
} // showStatus()

int main()
{
	cout << "Test " << __FILE__ << ' ' << __TIMESTAMP__ << endl;


	double a = 0.1; // Test decimal value chosen so cannot be stored exactly.

   // Show original control word and do calculation.
	unsigned int cwEntry = _controlfp(0, 0);
	cout << "On entry to main(), 87 FP control word register was " << hex << cwEntry << endl;
	unsigned int csEntry = _statusfp();
	cout << "On entry to main(), 87 FP status word register was " << hex << csEntry << '\n' << endl;

	double tiny = 1e-40; // < FLT_MIN 1.175494351e-38F /* min positive value */
	float y;
	y = tiny; // Expect inexact and underflow cos minimum float is e-38
	cout << "Expect Underflow & inexact. ";
	showStatus(); // includes clearfp

	double dblmax = DBL_MAX;
	float z = dblmax; // Too big for float so expect Overflow & inexact.
	cout << "Expect Underflow & inexact. ";
	showStatus();

	double b = y; // Too small from float so expect denorm.
	cout << "Expect Underflow, denorm & inexact. ";
	showStatus();


	// Try some calculations using different X87 floating point precisions.
	cout << setprecision(std::numeric_limits<double>::digits10 + 2) << endl;
	cout << dec << "a = " << a <<", a * a = " << a * a << endl;
  // Set precision using mask MCW_PC to new value _PC_24 for 24 mantissa bits.
	unsigned int cw2 = _controlfp( _PC_24, MCW_PC );
	cout << dec << "a = " << a <<", a * a = " << a * a << endl;

  // Set precision using mask MCW_PC to new value _PC_53 for 53 mantissa bits.
  unsigned int cw3 = _controlfp( _PC_53, MCW_PC );
	cout <<"Control word " <<hex << cw3 << dec << ", a = " << a <<", a * a = " << a * a << endl;
 	cout << setprecision(std::numeric_limits<float>::digits10 + 2)
		<< dec << "a = " << a <<", a * a = " << a * a << endl;
  // Set precision using mask MCW_PC to new value _PC_64 for 64 mantissa bits.
  unsigned int cw4 = _controlfp( _PC_64, MCW_PC );
	cout << setprecision(std::numeric_limits<double>::digits10 + 2)
		<< dec << "a = " << a <<", a * a = " << a * a << endl;

	// MS specific rounding.
	unsigned int rounding = _statusfp() & _MCW_RC;

	cout << "Rounding mode on entry was";
	if (rounding == _RC_NEAR)
		cout << " nearest";
	if (rounding & _RC_DOWN)
		cout << "  down";
	if (rounding & _RC_UP)
		cout << " up";
	if (rounding & _RC_CHOP)
		cout << " chop";
	cout << endl;

	// Std C++ rounding.
	enum float_round_style {
    round_indeterminate = -1,
    round_toward_zero = 0,
    round_to_nearest = 1,
    round_toward_infinity = 2,
    round_toward_neg_infinity = 3
    };
		 int round = std::numeric_limits<float>::round_style;

   cout << "Rounding style for float is " << round << ", ";

	 cout << ((round == round_indeterminate) ? "indeterminate" :
			(round == round_toward_zero) ? "toward zero" :
			(round == round_to_nearest) ? "to nearest" :
			(round == round_toward_infinity) ? "toward +infinity" :
			(round == round_toward_neg_infinity) ? "toward -infinity" : "?" ) << endl;


	const long double Knuth_pi = 3.1415926535897932384626433832795028841972L; // pi
	long double pi = Knuth_pi; // rounded nearest.
  std::cout << "pi rounded nearest = " << pi << std::endl;

	// Control rounding MS specific.
/*
#define _MCW_RC         0x00000300 Control
#define _RC_NEAR        0x00000000
#define _RC_DOWN        0x00000100
#define _RC_UP          0x00000200
#define _RC_CHOP        0x00000300
*/

  // Set precision using mask MCW_RC to new value for round up towards infinity bits.
	_clearfp();
	unsigned int cw6 = _controlfp(_RC_UP, _MCW_RC);
	cout << "Control word " << hex << cw6 << endl;
	unsigned int round_up = cw6 & _MCW_RC;
	// Check if reflected in control word.
	cout << "Rounding after  _controlfp(_RC_UP, _MCW_RC ) was" ;
	if (round_up == _RC_NEAR)
		cout << " nearest";
	if (round_up == _RC_DOWN)
		cout << "  down";
	if (round_up == _RC_UP)
		cout << " up";
	if (round_up == _RC_CHOP)
		cout << " chop";
	cout << endl;

	long double pi_hi = Knuth_pi;  // Rounded up.
	std::cout << "pi rounded up towards +infinity = " << pi_hi << std::endl;
	showStatus();

	unsigned int cw7 = _controlfp(_RC_DOWN, _MCW_RC);
	cout << "Control word " << hex << cw7 << endl;
	unsigned int round_down = cw7 & _MCW_RC;
	// Check if reflected in control word.
	cout << "Rounding after  _controlfp(_RC_DOWN, _MCW_RC ) was" ;
	if (round_down == _RC_NEAR)
		cout << " nearest";
	if (round_down == _RC_DOWN)
		cout << " down";
	if (round_down == _RC_UP)
		cout << " up";
	if (round_down == _RC_CHOP)
		cout << " chop";
	cout << endl;

	long double pi_lo = Knuth_pi; // Rounded down.
	showStatus();
	std::cout << "pi rounded down towards -infinity = " << pi_lo << std::endl;

	// Check if reflected in Std info.
	 round = std::numeric_limits<double>::round_style;
   cout << "Rounding style for double is " << round << ", ";
	 std::numeric_limits<double>::round_style;

	 cout << ((round == round_indeterminate) ? "indeterminate" :
			(round == round_toward_zero) ? "toward zero" :
			(round == round_to_nearest) ? "to nearest" :
			(round == round_toward_infinity) ? "toward +infinity" :
			(round == round_toward_neg_infinity) ? "toward -infinity" : "?" ) << endl;
			// Seems not on this implementation!

  // Restore all control word bits using mask  _CW_DEFAULTto default value.
  unsigned int cwExit = _controlfp( _CW_DEFAULT, 0xfffff);
	cout << hex << "_CW_DEFAULT = " << _CW_DEFAULT << ", mask = " << 0xfffff << endl;

	cout << "On exit from main(), X86 control word register was " << hex << cwExit << endl;
	cout << ((cwExit == cwEntry) ? "Same as on entry" : "Different from entry!") << endl;
	return 0;

}  // main

/*

X86 Control word

	Bit
	0	invalid
	1	denormalized
	2 zero divide
	3 overflow
	4 underflow
	5	precision
	6 & 7 reserved
	7 & 8 precision control
	9 & 10 rounding control
	12 reserved
	13	infinity control only for 8087 - infinity is always affine (-inf < +inf)
	14 & 15 reserved.
/*

Output:

Test J:\Cpp\constants\X86ControlWord\X86ControlWord.cpp Tue Mar 27 16:55:47 2001
On entry to main(), 87 FP control word register was 9001f
On entry to main(), 87 FP status word register was 0

Expect Underflow & inexact. 87 FP status word register  3  inexact underflow
Expect Underflow & inexact. 87 FP status word register  5  inexact overflow
Expect Underflow, denorm & inexact. 87 FP status word register  80000  denormal

a = 0.10000000000000001, a * a = 0.010000000000000002
a = 0.10000000000000001, a * a = 0.0099999997764825821
Control word 9001f, a = 0.10000000000000001, a * a = 0.010000000000000002
a = 0.1, a * a = 0.01
a = 0.10000000000000001, a * a = 0.010000000000000002
Rounding mode on entry was nearest
Rounding style for float is 1, to nearest
pi rounded nearest = 3.1415926535897931
Control word 8021f
Rounding after  _controlfp(_RC_UP, _MCW_RC ) was up
pi rounded up towards +infinity = 3.1415926535897931
87 FP status word register  0
Control word 8011f
Rounding after  _controlfp(_RC_DOWN, _MCW_RC ) was down
87 FP status word register  0
pi rounded down towards -infinity = 3.1415926535897931
Rounding style for double is 1, to nearest
_CW_DEFAULT = 9001f, mask = fffff
On exit from main(), X86 control word register was 9001f
Same as on entry
Press any key to continue

	*/