
#ifndef HPP_FUNCTION_CONSTANTS
#define HPP_FUNCTION_CONSTANTS

// Based on a post by Michael Kenniston:  http://groups.yahoo.com/group/boost/message/14867
// Written by J:\Cpp\WinNTL-5_0c\NTL5\makeConstants\makeConstants.cpp Tue Oct 16 15:40:55 2001
// Version 1.01
// Using Victor Shoup's NTL version 5.0c (www.shoup.net/ntl)

// (C) Copyright Paul A Bristow, hetp Chromatography, 2001, 2002
// Permission to copy, use, modify, sell and distribute this software
// is granted provided this copyright notice appears in all copies.
// This software is provided "as is" with express or implied warranty,
// and with no claim as to its suitability for any purpose.

// C++ Floating point types accurate to 40 decimal digits.

// For documentation and sources see constants.htm

// This file is a collection of the most basic mathematical constants.

// The objective is to achieve the full accuracy possible
// with IEC559/IEEE745 Floating point hardware and C++ language.
// This has no extra cost to the user, but reduces irritating effects
// caused by the inevitable limitations of floating point calculations.
// At least these manifest as spurious least significant digits,
// at worst algorithms that fail because comparisons fail.
// 40 decimal places ensures no loss of accuracy even for 128-bit floating point.

namespace boost {
  namespace math {
    template <typename Tag, typename Rep = double>
    struct constant
    { // The "constant" class/struct provides a place to put
      // the actual definition of the value of each constant.
			 // It also turns an implicit conversion operation
			 // (which does not need any parentheses) into an explicit call to the
			 // correct function that actually knows (and returns) the right value.
      constant() {} // Returns the value of the constant.
      operator Rep() const; // Fully specialized for each Rep/Tag pair.
    };
  } // namespace math
} // namespace boost



namespace boost{
  namespace math
  {
    struct pi_tag {};
    namespace float_constants
    {
      constant<pi_tag, float> const pi;
    }
    namespace double_constants
    {
      constant<pi_tag, double> const pi;
    }
    namespace long_double_constants
    {
      constant<pi_tag, long double> const pi;
    }
    template<> inline constant<pi_tag, long double>::operator long double() const
    {
      return 3.141592653589793238462643383279502884197L;
    }
    template<> inline constant<pi_tag, double>::operator double() const
    {
      return 3.141592653589793238462643383279502884197;
    }
    template<> inline constant<pi_tag, float>::operator float() const
    {
      return 3.141592653589793238462643383279502884197F;
    }
  }// namespace math
} // namespace boost


namespace boost{
  namespace math
  {
    struct sqrt2_tag {};
    namespace float_constants
    {
      constant<sqrt2_tag, float> const sqrt2;
    }
    namespace double_constants
    {
      constant<sqrt2_tag, double> const sqrt2;
    }
    namespace long_double_constants
    {
      constant<sqrt2_tag, long double> const sqrt2;
    }
    template<> inline constant<sqrt2_tag, long double>::operator long double() const
    {
      return 1.41421356237309504880168872420969807857L;
    }
    template<> inline constant<sqrt2_tag, double>::operator double() const
    {
      return 1.41421356237309504880168872420969807857;
    }
    template<> inline constant<sqrt2_tag, float>::operator float() const
    {
      return 1.41421356237309504880168872420969807857F;
    }
  }// namespace math
} // namespace boost


namespace boost{
  namespace math
  {
    struct e_tag {};
    namespace float_constants
    {
      constant<e_tag, float> const e;
    }
    namespace double_constants
    {
      constant<e_tag, double> const e;
    }
    namespace long_double_constants
    {
      constant<e_tag, long double> const e;
    }
    template<> inline constant<e_tag, long double>::operator long double() const
    {
      return 0.5772156649015328606065120900824024310422L;
    }
    template<> inline constant<e_tag, double>::operator double() const
    {
      return 0.5772156649015328606065120900824024310422;
    }
    template<> inline constant<e_tag, float>::operator float() const
    {
      return 0.5772156649015328606065120900824024310422F;
    }
  }// namespace math
} // namespace boost


#endif
// End of function_constants.hpp
