// Builtin math constants

// Example of using builitn constant pi
// NOT used by BOOST math_constants.

#include <iostream>
#include <iomanip> // for setprecision
#include <limits> // for numeric_limits

#include "builtin_constants.h" // Uses X86 fldpi instruction.

using std::cout;
using std::endl;
using std::setprecision;

const long double Knuth_pi = 3.1415926535897932384626433832795028841972L; // pi


int main()
{
	cout << "Test " << __FILE__ << ' ' << __TIMESTAMP__ << endl;

	double myPi = mathconst<double>::pi();

	cout << "myPi as double (default precision 6 decimal digits) is " << myPi << endl;

	cout << setprecision(std::numeric_limits<double>::digits10 + 2);
	// Ensure all significant digits and two noisy digits are displayed.

	cout << "myPi as double (all significant digits and two noisy) is " << mathconst<double>::pi() << endl;


  std::cout << "mathconst<long double>::pi() " << mathconst<long double>::pi() << std::endl;
  std::cout << "Knuth_pi " << Knuth_pi << std::endl;
  std::cout << "FP pi - Knuth_pi =  " << Knuth_pi - mathconst<long double>::pi() << std::endl;

	return 0;
}

/*

	Test J:\Cpp\constants\Builtin_constants\builtin_constants.cpp Mon Mar 26 23:28:03
 2001
myPi as double (default precision 6 decimal digits) is 3.14159
myPi as double (all significant digits and two noisy) is 3.1415926535897931
mathconst<long double>::pi() 3.1415926535897931
Knuth_pi 3.1415926535897931
FP pi - Knuth_pi =  0
Press any key to continue

*/

/* (C) Copyright Paul A Bristow, hetp Chromatography, 2001
 Permission to copy, use, modify, sell and distribute this software
 is granted provided this copyright notice appears in all copies.
 This software is provided "as is" with express or implied warranty,
 and with no claim as to its suitability for any purpose.*/

